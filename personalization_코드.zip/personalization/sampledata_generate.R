# 분석에 적합한 data를 생성하기 위한 용도로, 
# 특정한 논리나 특별한 의미가 있는 코드가 있는 것은 아니기
# 때문에, skip 하셔도 됩니다.

#install.packages("dplyr")
library(dplyr)

###########################################################################3333333
# data 분석을 위한 sample data 생성
# apriori, 위도 경도 계산을 위한 sample data generation

# sampleData.csv에는 주소 정보를 받아옴.
#(공공 데이터에서 상점 데이터 주소를 가져옴)
# 상점 데이터이기 때문에, 1층, 2층 등의 정보로 인해 
# 좌표 변환 오류가 생기는 경우가 있는데, 실제 구현시에는 
# 해당 문제는 데이터 분석 단계에서 발생 x. 주소를 정해진 형식으로
# 제공받을 예정.
data<-read.csv("sampleData.csv")


###### apriori용 최근 거래 목록 데이터 generate
# 이용자의  id + 최근 거래 목록형태의 데이터 셋 generate
catList=rep(c("유학수속","부동산","병원",
              "공문서 처리","금융","여행"),106)
#length(catList)
catList=c(catList,c("유학수속","부동산","병원",
                    "공문서 처리"))

data<-data %>% mutate(id=paste("userId_",1:dim(data)[1])) %>% 
  mutate(score=1) %>% mutate(category=catList)

index = sample(1:nrow(data), 0.7*nrow(data))
data_step1<-data[index,]
catList_step1=rep(c("유학수속","부동산","병원",
              "공문서 처리"),112)

data_step1<-data_step1 %>% mutate(category=catList_step1)
index = sample(1:nrow(data), 0.7*nrow(data))
data_step2<-data[index,]
catList_step2=rep(c("유학수속","부동산","병원",
                    "공문서 처리"),112)
data_step2<-data_step2 %>% mutate(category=catList_step1)

#data[-index,]$score=-1
data_apriori<-data %>% rbind(data_step1) %>% rbind(data_step2) %>%
arrange(id)

head(data_apriori)
dim(data_apriori)

# apriori용 데이터 생성 완료
write.csv(data_apriori,"sample_apriori.csv",fileEncoding = "EUC-KR")

################################################################################
# 기타 데이터들도 같은 방식으로 generate하거나, 분석에 맞게 직접 제작.

