# 위도 경도 계산 및 지도에 점찍기 test

#install packages
#install.packages("ggmap")
#install.packages("ggplot2")
#library packages
library(ggplot2)
library(ggmap)
library(dplyr)

# data 읽기
data<-read.csv("geocoding_sample.csv")
head(data)
# encoding
data$new_address<-as.character(data$new_address)
data$new_address<-enc2utf8(data$new_address)

# using google map api, 좌표 변환 
data_lonlat<-mutate_geocode(data,new_address,source='google')

# geocoding data
final_data<-data_lonlat %>% filter(!is.na(lon)) %>% filter(!is.na(lat))
View(final_data)

write.csv(final_data,"georesult.csv", fileEncoding = "EUC-KR")

##############map에 그림 그리기
#map 불러오기
seoul_city<-get_map("seoul",zoom=11,maptype = "roadmap")

# image 저장 

# 점찍기 test
seoul_map<-ggmap(seoul_city)+geom_point(data=final_data,aes(x=lon,y=lat),
                                        size=2,alpha=0.6,color="red")
seoul_map

# save map
# ggsave(filename="sample_map2.png")


