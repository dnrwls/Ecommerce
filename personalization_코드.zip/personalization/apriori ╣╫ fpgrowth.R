###apriori
#install.packages("dplyr)
#install.packages("arules")
library(arules)
library(dplyr)

#data 불러오기
data_apriori<-read.csv("sample_apriori.csv")

apData<-data_apriori %>% select(id,category)

# transfer data to transaction structure
model_for_transaction<-function(apData){
  apData_for_split<-split(apData$category,apData$id)
  apData_transaction<-as(apData_for_split,"transactions")  
  return (apData_transaction)
}
data_trans<-model_for_transaction(apData)

# model 돌리기
rules=apriori(data_trans,parameter=list(supp=.1,conf=.1,minlen=2)) #parameter 조정
summary(rules)
rule.list<-as.data.frame(inspect(rules))
rule.list
write.csv(rule.list,"연관성 분석결과.csv",fileEncoding = "EUC-KR")

