#install.packages("ggmap")
#install.packages("ggplot2")
#install.packages("dplyr")
library(ggmap)
library(ggplot2)
library(dplyr)
# 시나리오 1
# user의 카테고리가 부동산일 때, seller 카테고리 부동산인 것 filter,
# 거리계산.

buyer_data<-read.csv("최종_buyer.csv")
seller_data<-read.csv("최종_seller.csv")
result<-read.csv("연관성결과.csv")
# target buyer 여기서는 첫번째 buyer를 타겟으로.
buyer_data[1,] %>% as.vector()


# target buyer와 동일한 category filter
filter_seller<-seller_data %>% filter(category==buyer_data$category[1] %>% as.vector())
filter_seller$category

# define degree to radian function
deg_rad<-function(deg){
  (deg*pi)/180
}
# counting distance function
count_distance<-function(buyer_data,seller_data){
  buyer_lon=buyer_data$lon[1] # 이용자에 따라 값 변경
  buyer_lat=buyer_data$lat[1]
  
  # just assume buyer's longtitude,latitude as rest of data
  seller_lon=filter_seller$lon
  seller_lat=filter_seller$lat
  
  #
  lat1 = deg_rad(buyer_lat)
  lon1 = deg_rad(buyer_lon)
  lat2 = deg_rad(seller_lat)
  lon2 = deg_rad(seller_lon)
  
  #
  dlon = lon2 - lon1
  dlat = lat2 - lat1
  
  a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
  c = 2 * atan2(sqrt(a), sqrt(1 - a))
  
  
  #
  R=6373 #km
  distance=R*c
  return(distance)
}

distance=count_distance(buyer_data,filter_seller)
length(distance)
##################################################################
#거리 계산 test
#  test_distance computing
check_distance<-filter_seller %>%  
  select(sellerId,lon,lat) %>% mutate(distance=distance) %>% arrange(distance)
print(check_distance[1:5,]$sellerId %>% as.vector())


# draw a map
#map 불러오기 google map api 연결
seoul_city<-get_map("seoul",zoom=11,maptype = "roadmap")

# 점찍기
user_point<-buyer_data[1,] %>% select(lon,lat)
close_point<-check_distance[1:5,]
other_point<-check_distance[6:nrow(check_distance),]
seoul_map<-ggmap(seoul_city)+ geom_point(data=close_point,aes(x=lon,y=lat),
                                         size=5,alpha=0.6,color="red")+
  geom_point(data=user_point,aes(x=lon,y=lat),
             size=5,alpha=0.6,color="blue")+
  geom_point(data=other_point,aes(x=lon,y=lat),
             size=2,alpha=0.6,color="black")
seoul_map
print(check_distance[1:5,]$sellerId %>% as.vector())
# save png file
# ggsave(filename="sample_close_points.png")




