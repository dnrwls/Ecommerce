﻿<?php
	phpinfo();
?>